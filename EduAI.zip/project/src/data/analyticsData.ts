export const analyticsData = {
  strengths: [
    {
      title: 'Mathematics',
      score: 92,
      details: {
        strengths: [
          'Exceptional problem-solving skills',
          'Strong grasp of calculus concepts',
          'Advanced algebraic manipulation',
          'Quick mental calculations'
        ],
        recentProgress: 'Improved score by 5% in the last month',
        nextSteps: [
          'Explore advanced topology',
          'Start complex analysis',
          'Practice more real-world applications'
        ]
      }
    },
    {
      title: 'Physics',
      score: 88,
      details: {
        strengths: [
          'Strong theoretical understanding',
          'Excellent lab work',
          'Good mathematical application',
          'Intuitive grasp of mechanics'
        ],
        recentProgress: 'Consistent performance in quantum mechanics',
        nextSteps: [
          'Deep dive into quantum field theory',
          'Practice more numerical problems',
          'Start advanced laboratory experiments'
        ]
      }
    },
    {
      title: 'Programming',
      score: 90,
      details: {
        strengths: [
          'Clean and efficient code writing',
          'Strong debugging skills',
          'Good software architecture knowledge',
          'Fast problem-solving ability'
        ],
        recentProgress: 'Completed 3 major projects in the last month',
        nextSteps: [
          'Learn new programming paradigms',
          'Contribute to open source',
          'Build more complex applications'
        ]
      }
    }
  ],
  improvements: [
    {
      title: 'Literature',
      score: 65,
      details: {
        recommendations: [
          'Read more classic literature',
          'Practice critical analysis',
          'Improve writing structure',
          'Enhance vocabulary'
        ],
        recentProgress: 'Slight improvement in essay writing',
        nextSteps: [
          'Start a reading challenge',
          'Join writing workshops',
          'Practice daily writing exercises'
        ]
      }
    },
    {
      title: 'History',
      score: 70,
      details: {
        recommendations: [
          'Focus on chronological understanding',
          'Practice source analysis',
          'Improve essay structure',
          'Read more historical texts'
        ],
        recentProgress: 'Better understanding of modern history',
        nextSteps: [
          'Create detailed timelines',
          'Watch historical documentaries',
          'Practice essay writing'
        ]
      }
    },
    {
      title: 'Chemistry',
      score: 75,
      details: {
        recommendations: [
          'Review basic concepts',
          'Practice more lab work',
          'Focus on organic chemistry',
          'Improve equation balancing'
        ],
        recentProgress: 'Improved understanding of organic compounds',
        nextSteps: [
          'Complete practice problems',
          'Attend extra lab sessions',
          'Create study flashcards'
        ]
      }
    }
  ]
};