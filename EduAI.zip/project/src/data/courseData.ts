import { SubjectSyllabus } from '../types/course';

export const courseData: SubjectSyllabus[] = [
  {
    title: 'Biology',
    description: 'Comprehensive biology from basics to advanced concepts',
    image: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800&q=80',
    progress: 0,
    details: {
      objectives: [
        'Understand cell biology and genetics',
        'Learn human anatomy and physiology',
        'Study ecology and environmental science',
        'Master molecular biology concepts'
      ],
      prerequisites: ['Basic science knowledge'],
      duration: '48 weeks',
      nextMilestone: 'Cell Biology Fundamentals'
    },
    syllabus: {
      'Class 1-5': [
        'Living and Non-living Things',
        'Parts of Plants and Animals',
        'Human Body Systems',
        'Environmental Science Basics'
      ],
      'Class 6-10': [
        'Cell Structure and Function',
        'Plant and Animal Tissues',
        'Human Physiology',
        'Genetics Basics'
      ],
      'Class 11-12': [
        'Advanced Cell Biology',
        'Molecular Basis of Inheritance',
        'Human Physiology',
        'Biotechnology'
      ],
      'Undergraduate': [
        'Biochemistry',
        'Microbiology',
        'Genetics and Evolution',
        'Biotechnology Applications'
      ]
    }
  },
  {
    title: 'Chemistry',
    description: 'Interactive chemistry learning with virtual lab experiments',
    image: 'https://images.unsplash.com/photo-1532634922-8fe0b757fb13?auto=format&fit=crop&w=800&q=80',
    progress: 0,
    details: {
      objectives: [
        'Master organic chemistry concepts',
        'Understand inorganic chemistry',
        'Learn physical chemistry principles',
        'Practice chemical calculations'
      ],
      prerequisites: ['Basic mathematics'],
      duration: '48 weeks',
      nextMilestone: 'Atomic Structure'
    },
    syllabus: {
      'Class 1-5': [
        'Matter and its Properties',
        'Elements and Compounds',
        'Simple Chemical Reactions',
        'Basic Laboratory Safety'
      ],
      'Class 6-10': [
        'Atomic Structure',
        'Chemical Bonding',
        'Acids, Bases, and Salts',
        'Organic Chemistry Introduction'
      ],
      'Class 11-12': [
        'Chemical Thermodynamics',
        'Chemical Kinetics',
        'Organic Chemistry',
        'Electrochemistry'
      ],
      'Undergraduate': [
        'Advanced Organic Chemistry',
        'Coordination Chemistry',
        'Quantum Chemistry',
        'Industrial Chemistry'
      ]
    }
  },
  {
    title: 'Python Programming',
    description: 'Learn Python from basics to advanced applications',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    progress: 0,
    details: {
      objectives: [
        'Master Python fundamentals',
        'Learn object-oriented programming',
        'Develop web applications',
        'Build AI and ML projects'
      ],
      prerequisites: ['Basic computer knowledge'],
      duration: '24 weeks',
      nextMilestone: 'Basic Syntax and Data Types'
    },
    syllabus: {
      'Beginner': [
        'Python Basics',
        'Data Types and Variables',
        'Control Structures',
        'Functions'
      ],
      'Intermediate': [
        'Object-Oriented Programming',
        'File Handling',
        'Error Handling',
        'Modules and Packages'
      ],
      'Advanced': [
        'Web Development with Django',
        'Data Science with Python',
        'Machine Learning Basics',
        'API Development'
      ]
    }
  },
  {
    title: 'Java Programming',
    description: 'Complete Java development course with practical projects',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
    progress: 0,
    details: {
      objectives: [
        'Master Java fundamentals',
        'Learn enterprise development',
        'Build Android applications',
        'Understand Spring framework'
      ],
      prerequisites: ['Basic programming concepts'],
      duration: '36 weeks',
      nextMilestone: 'Java Basics'
    },
    syllabus: {
      'Beginner': [
        'Java Fundamentals',
        'Object-Oriented Concepts',
        'Exception Handling',
        'Collections Framework'
      ],
      'Intermediate': [
        'Multithreading',
        'File I/O',
        'JDBC',
        'Servlets and JSP'
      ],
      'Advanced': [
        'Spring Framework',
        'Hibernate ORM',
        'RESTful Services',
        'Microservices'
      ]
    }
  }
];