import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Brain, Briefcase, BookOpen } from 'lucide-react';
import { Modal } from '../components/Modal';

const assessments = [
  {
    title: 'Career Assessment',
    icon: Briefcase,
    description: 'Discover career paths that match your skills and interests',
    questions: [
      'What subjects do you enjoy the most?',
      'How do you prefer to solve problems?',
      'What kind of work environment do you thrive in?',
      'What are your long-term career goals?'
    ]
  },
  {
    title: 'Learning Style Analysis',
    icon: Brain,
    description: 'Understand your optimal learning methods',
    questions: [
      'How do you prefer to consume information?',
      'What time of day are you most productive?',
      'Do you learn better alone or in groups?',
      'How do you best remember new information?'
    ]
  },
  {
    title: 'Skill Assessment',
    icon: BookOpen,
    description: 'Evaluate your current skill levels across different areas',
    questions: [
      'Rate your problem-solving abilities',
      'How comfortable are you with technology?',
      'Assess your communication skills',
      'Rate your analytical thinking'
    ]
  }
];

export function ExplorePage() {
  const [selectedAssessment, setSelectedAssessment] = useState<typeof assessments[0] | null>(null);

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Explore Your Potential</h1>
          <p className="mt-2 text-gray-600">
            Take assessments to discover your strengths and opportunities for growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {assessments.map((assessment, index) => (
            <div
              key={index}
              onClick={() => setSelectedAssessment(assessment)}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            >
              <div className="flex items-center justify-center w-12 h-12 bg-indigo-100 rounded-lg mb-4">
                <assessment.icon className="h-6 w-6 text-indigo-600" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{assessment.title}</h2>
              <p className="text-gray-600">{assessment.description}</p>
            </div>
          ))}
        </div>

        <Modal
          isOpen={!!selectedAssessment}
          onClose={() => setSelectedAssessment(null)}
          title={selectedAssessment?.title || ''}
        >
          <div className="space-y-6">
            <p className="text-gray-600">{selectedAssessment?.description}</p>
            
            <div className="space-y-4">
              {selectedAssessment?.questions.map((question, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-lg">
                  <p className="font-medium text-gray-900">Question {index + 1}</p>
                  <p className="mt-1 text-gray-600">{question}</p>
                  <textarea
                    className="mt-2 w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    rows={3}
                    placeholder="Your answer..."
                  />
                </div>
              ))}
            </div>

            <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
              Submit Assessment
            </button>
          </div>
        </Modal>
      </div>
    </DashboardLayout>
  );
}