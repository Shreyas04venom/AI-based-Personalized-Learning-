import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { DashboardLayout } from '../components/DashboardLayout';

export function WelcomePage() {
  const user = useAuthStore((state) => state.user);

  if (!user) {
    return <Navigate to="/" replace />;
  }

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome, {user.name}! 👋
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Your personalized learning journey begins here. Let's explore your potential together.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Start Learning</h2>
            <p className="text-gray-600 mb-4">
              Choose from a variety of subjects and begin your personalized learning path.
            </p>
            <a href="/learn" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Explore subjects →
            </a>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Track Progress</h2>
            <p className="text-gray-600 mb-4">
              View your analytics and see how you're improving across different subjects.
            </p>
            <a href="/analytics" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Check analytics →
            </a>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Discover Interests</h2>
            <p className="text-gray-600 mb-4">
              Take assessments to understand your strengths and potential career paths.
            </p>
            <a href="/explore" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Start assessment →
            </a>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}