import React from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { AnalyticsItem } from '../components/AnalyticsCard';
import { analyticsData } from '../data/analyticsData';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const progressData = [
  { month: 'Jan', Mathematics: 82, Physics: 78, Programming: 85 },
  { month: 'Feb', Mathematics: 85, Physics: 80, Programming: 87 },
  { month: 'Mar', Mathematics: 88, Physics: 83, Programming: 88 },
  { month: 'Apr', Mathematics: 92, Physics: 88, Programming: 90 },
];

export function AnalyticsPage() {
  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Your Learning Analytics</h1>
          <p className="mt-2 text-gray-600">
            Track your progress and identify areas for improvement.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">Progress Over Time</h2>
            <div className="w-full h-[300px]">
              <LineChart width={500} height={300} data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="Mathematics" stroke="#8884d8" />
                <Line type="monotone" dataKey="Physics" stroke="#82ca9d" />
                <Line type="monotone" dataKey="Programming" stroke="#ffc658" />
              </LineChart>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <h2 className="text-xl font-semibold mb-4">Your Strengths</h2>
              <div className="space-y-2">
                {analyticsData.strengths.map((item, index) => (
                  <AnalyticsItem key={index} {...item} type="strength" />
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <h2 className="text-xl font-semibold mb-4">Areas for Improvement</h2>
              <div className="space-y-2">
                {analyticsData.improvements.map((item, index) => (
                  <AnalyticsItem key={index} {...item} type="improvement" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}