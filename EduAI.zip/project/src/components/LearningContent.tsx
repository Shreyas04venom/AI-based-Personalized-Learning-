import React from 'react';
import { BookOpen, Video, GameController, FileText } from 'lucide-react';

interface LearningContentProps {
  subject: string;
  topic: string;
}

export function LearningContent({ subject, topic }: LearningContentProps) {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer">
          <div className="flex items-center space-x-3 mb-4">
            <Video className="h-6 w-6 text-indigo-600" />
            <h3 className="font-semibold text-lg">Video Lessons</h3>
          </div>
          <p className="text-gray-600">Interactive video tutorials with AI-powered explanations</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer">
          <div className="flex items-center space-x-3 mb-4">
            <FileText className="h-6 w-6 text-green-600" />
            <h3 className="font-semibold text-lg">Text Content</h3>
          </div>
          <p className="text-gray-600">Comprehensive study materials and notes</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer">
          <div className="flex items-center space-x-3 mb-4">
            <GameController className="h-6 w-6 text-purple-600" />
            <h3 className="font-semibold text-lg">Interactive Games</h3>
          </div>
          <p className="text-gray-600">Learn through engaging educational games</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer">
          <div className="flex items-center space-x-3 mb-4">
            <BookOpen className="h-6 w-6 text-orange-600" />
            <h3 className="font-semibold text-lg">Practice Tests</h3>
          </div>
          <p className="text-gray-600">AI-generated quizzes and assessments</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-2xl font-bold mb-4">AI Teaching Assistant</h2>
        <div className="border rounded-lg p-4">
          <div className="flex items-start space-x-4">
            <div className="flex-1">
              <div className="bg-gray-100 p-4 rounded-lg mb-4">
                <p className="text-gray-700">
                  Ask any question about {topic} in {subject}
                </p>
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Type your question..."
                  className="flex-1 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                  Ask AI
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}