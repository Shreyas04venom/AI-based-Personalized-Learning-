import React, { useState } from 'react';
import { Award, Target } from 'lucide-react';
import { Modal } from './Modal';

interface AnalyticsItemProps {
  title: string;
  score: number;
  details: {
    strengths?: string[];
    recommendations?: string[];
    recentProgress?: string;
    nextSteps?: string[];
  };
  type: 'strength' | 'improvement';
}

export function AnalyticsItem({ title, score, details, type }: AnalyticsItemProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const Icon = type === 'strength' ? Award : Target;
  const colorClass = type === 'strength' ? 'text-green-500' : 'text-orange-500';

  return (
    <>
      <div 
        onClick={() => setIsModalOpen(true)}
        className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
      >
        <Icon className={`h-4 w-4 ${colorClass}`} />
        <span className="text-gray-700">{title}: {score}%</span>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`${title} Analysis`}
      >
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <Icon className={`h-8 w-8 ${colorClass}`} />
            <div>
              <h4 className="font-semibold text-xl">{score}%</h4>
              <p className="text-gray-600">Current Performance</p>
            </div>
          </div>

          {type === 'strength' && details.strengths && (
            <div>
              <h4 className="font-semibold text-lg mb-2">Key Strengths</h4>
              <ul className="list-disc list-inside space-y-1">
                {details.strengths.map((strength, index) => (
                  <li key={index} className="text-gray-700">{strength}</li>
                ))}
              </ul>
            </div>
          )}

          {type === 'improvement' && details.recommendations && (
            <div>
              <h4 className="font-semibold text-lg mb-2">Recommendations</h4>
              <ul className="list-disc list-inside space-y-1">
                {details.recommendations.map((rec, index) => (
                  <li key={index} className="text-gray-700">{rec}</li>
                ))}
              </ul>
            </div>
          )}

          <div>
            <h4 className="font-semibold text-lg mb-2">Recent Progress</h4>
            <p className="text-gray-700">{details.recentProgress}</p>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-2">Next Steps</h4>
            <ul className="list-disc list-inside space-y-1">
              {details.nextSteps?.map((step, index) => (
                <li key={index} className="text-gray-700">{step}</li>
              ))}
            </ul>
          </div>
        </div>
      </Modal>
    </>
  );
}