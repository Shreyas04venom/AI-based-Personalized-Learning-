import React, { useState } from 'react';
import { BookCheck, ChevronRight } from 'lucide-react';
import { Modal } from './Modal';

interface CourseProps {
  title: string;
  description: string;
  image: string;
  progress: number;
  details: {
    objectives: string[];
    prerequisites: string[];
    duration: string;
    nextMilestone: string;
  };
}

export function CourseCard({ title, description, image, progress, details }: CourseProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="bg-white rounded-xl shadow-md overflow-hidden group hover:shadow-lg transition-shadow">
        <div 
          className="h-48 overflow-hidden cursor-pointer" 
          onClick={() => setIsModalOpen(true)}
        >
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
          />
        </div>
        <div className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4">{description}</p>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookCheck className="h-5 w-5 text-indigo-600" />
              <span className="text-sm text-gray-600">{progress}% Complete</span>
            </div>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex items-center text-indigo-600 hover:text-indigo-700"
            >
              Continue <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={title}
      >
        <div className="space-y-6">
          <img src={image} alt={title} className="w-full h-64 object-cover rounded-lg" />
          
          <div>
            <h4 className="font-semibold text-lg mb-2">Course Objectives</h4>
            <ul className="list-disc list-inside space-y-1">
              {details.objectives.map((objective, index) => (
                <li key={index} className="text-gray-700">{objective}</li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-2">Prerequisites</h4>
            <ul className="list-disc list-inside space-y-1">
              {details.prerequisites.map((prerequisite, index) => (
                <li key={index} className="text-gray-700">{prerequisite}</li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-1">Duration</h4>
              <p className="text-gray-700">{details.duration}</p>
            </div>
            <div>
              <h4 className="font-semibold mb-1">Next Milestone</h4>
              <p className="text-gray-700">{details.nextMilestone}</p>
            </div>
          </div>

          <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
            Continue Learning
          </button>
        </div>
      </Modal>
    </>
  );
}