import React from 'react';
import { Brain } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-8 w-8 text-indigo-600" />
            <span className="text-xl font-bold text-gray-900">LearnSmart AI</span>
          </div>
          <nav className="flex space-x-8">
            <a href="#analytics" className="text-gray-700 hover:text-indigo-600">Analytics</a>
            <a href="#learn" className="text-gray-700 hover:text-indigo-600">Learn</a>
            <a href="#explore" className="text-gray-700 hover:text-indigo-600">Explore</a>
          </nav>
        </div>
      </div>
    </header>
  );
}