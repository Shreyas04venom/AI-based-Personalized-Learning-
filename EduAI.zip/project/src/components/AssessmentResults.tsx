import React from 'react';
import { Award, Target, BookOpen } from 'lucide-react';

interface AssessmentResultsProps {
  type: 'career' | 'learning' | 'skill';
  results: {
    title: string;
    description: string;
    recommendations: string[];
    score?: number;
  };
}

export function AssessmentResults({ type, results }: AssessmentResultsProps) {
  const icons = {
    career: Award,
    learning: BookOpen,
    skill: Target
  };

  const Icon = icons[type];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <div className="bg-indigo-100 p-3 rounded-full">
          <Icon className="h-6 w-6 text-indigo-600" />
        </div>
        <div>
          <h3 className="text-xl font-semibold">{results.title}</h3>
          <p className="text-gray-600">{results.description}</p>
        </div>
      </div>

      {results.score && (
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-gray-700">Overall Score</span>
            <span className="text-2xl font-bold text-indigo-600">{results.score}%</span>
          </div>
        </div>
      )}

      <div>
        <h4 className="font-semibold text-lg mb-3">Recommendations</h4>
        <ul className="space-y-2">
          {results.recommendations.map((rec, index) => (
            <li key={index} className="flex items-start space-x-2">
              <span className="text-indigo-600">•</span>
              <span className="text-gray-700">{rec}</span>
            </li>
          ))}
        </ul>
      </div>

      <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
        Start Recommended Path
      </button>
    </div>
  );
}