export interface SubjectSyllabus {
  title: string;
  description: string;
  image: string;
  progress: number;
  details: {
    objectives: string[];
    prerequisites: string[];
    duration: string;
    nextMilestone: string;
  };
  syllabus: {
    [key: string]: string[];
  };
}