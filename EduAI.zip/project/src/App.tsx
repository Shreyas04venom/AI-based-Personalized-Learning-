import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { SignUpPage } from './pages/SignUpPage';
import { WelcomePage } from './pages/WelcomePage';
import { LearnPage } from './pages/LearnPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExplorePage } from './pages/ExplorePage';
import { useAuthStore } from './store/authStore';

function App() {
  const user = useAuthStore((state) => state.user);

  return (
    <Router>
      <Routes>
        <Route path="/" element={!user ? <SignUpPage /> : <Navigate to="/welcome" replace />} />
        <Route path="/welcome" element={<WelcomePage />} />
        <Route path="/learn" element={<LearnPage />} />
        <Route path="/analytics" element={<AnalyticsPage />} />
        <Route path="/explore" element={<ExplorePage />} />
      </Routes>
    </Router>
  );
}

export default App;